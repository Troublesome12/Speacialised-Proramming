public class UnsealTheSafe {
    
    public long countPasswords(int N) {

        return 0;
    }

    public static void main(String[] args) {
        System.out.println(new UnsealTheSafe().countPasswords(2));       // 26
        System.out.println(new UnsealTheSafe().countPasswords(3));       // 74
        System.out.println(new UnsealTheSafe().countPasswords(25));      // 768478331222

    }
}
